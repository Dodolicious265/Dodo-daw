package com.dodolab.studio

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private val purple = 0xFFB77AFF.toInt()
    private val bg = 0xFF100D18.toInt()
    private val panel = 0xFF21192D.toInt()
    private val white = 0xFFF7F2FF.toInt()
    private val muted = 0xFFB9ADC7.toInt()
    private val recorder = AudioRecorder()
    private var beatUri: Uri? = null
    private var player: MediaPlayer? = null
    private var bpm = 140
    private var countIn: CountDownTimer? = null
    private lateinit var status: TextView
    private lateinit var beatLabel: TextView
    private lateinit var recordButton: Button
    private lateinit var trackList: LinearLayout
    private val takes = mutableListOf<File>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("dodo", 30, purple, true))
        header.addView(label("LAB", 30, white, true))
        val version = label("NATIVE ALPHA", 10, muted, true).apply { setPadding(12, 8, 0, 0) }
        header.addView(version)
        content.addView(header)
        content.addView(label("MOBILE AUDIO WORKSTATION", 10, muted, true).apply { setPadding(0, 2, 0, 18) })

        content.addView(section("SESSION"))
        val bpmRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(14, 12, 14, 12); background = rounded(panel, 16) }
        bpmRow.addView(label("TEMPO", 12, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        val minus = smallButton("−") { bpm = (bpm - 1).coerceAtLeast(40); bpmValue.text = bpm.toString() }
        val bpmValue = label(bpm.toString(), 20, white, true)
        val plus = smallButton("+") { bpm = (bpm + 1).coerceAtMost(240); bpmValue.text = bpm.toString() }
        bpmRow.addView(minus); bpmRow.addView(bpmValue); bpmRow.addView(plus)
        content.addView(bpmRow)

        content.addView(section("BEAT / INSTRUMENTAL"))
        beatLabel = label("No instrumental imported", 13, muted, false).apply { setPadding(14, 14, 14, 14); background = rounded(panel, 14) }
        content.addView(beatLabel)
        content.addView(actionButton("IMPORT INSTRUMENTAL", false) { chooseBeat() })

        content.addView(section("RECORDING DECK"))
        status = label("Ready · headphones recommended", 12, muted, false).apply { gravity = Gravity.CENTER; setPadding(8, 16, 8, 16) }
        content.addView(status)
        recordButton = actionButton("●  RECORD OVER BEAT", true) { toggleRecording() }
        content.addView(recordButton)
        content.addView(actionButton("▶  PLAY / STOP BEAT", false) { toggleBeatPlayback() })

        content.addView(section("RECORDED TAKES"))
        trackList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(panel, 14); setPadding(12, 8, 12, 8) }
        trackList.addView(label("Your vocal takes will appear here.", 12, muted, false).apply { setPadding(4, 12, 4, 12) })
        content.addView(trackList)
        content.addView(section("ENGINE STATUS"))
        content.addView(label("Native Android microphone capture · 44.1 kHz · 16-bit mono WAV\nBeat playback currently uses Android MediaPlayer. Recording/playback timing is an early alpha and is not yet sample-accurate.", 11, muted, false).apply { setPadding(12, 14, 12, 14); background = rounded(panel, 14) })
        content.addView(label("dodoLAB · Build 0.4 Native Alpha", 10, muted, false).apply { gravity = Gravity.CENTER; setPadding(0, 24, 0, 8) })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private lateinit var bpmValue: TextView

    private fun section(name: String) = label(name, 11, purple, true).apply { setPadding(2, 22, 2, 9) }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD) }
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    }
    private fun smallButton(text: String, click: () -> Unit) = Button(this).apply { this.text = text; textSize = 16f; setTextColor(white); setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF382747.toInt())); setOnClickListener { click() } }
    private fun actionButton(text: String, primary: Boolean, click: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 12f; isAllCaps = false; setTextColor(if (primary) bg else white)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (primary) purple else 0xFF332640.toInt()))
        val p = LinearLayout.LayoutParams(-1, 54); p.topMargin = 9; layoutParams = p
        setOnClickListener { click() }
    }

    private fun chooseBeat() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*" }
        startActivityForResult(intent, 20)
    }

    @Deprecated("Deprecated in Android API but retained for Android 7 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20 && resultCode == RESULT_OK) {
            beatUri = data?.data
            beatLabel.text = beatUri?.lastPathSegment?.substringAfterLast('/') ?: "Instrumental selected"
            try { contentResolver.takePersistableUriPermission(beatUri!!, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            status.text = "Instrumental loaded · ready to record"
        }
    }

    private fun toggleBeatPlayback() {
        if (player?.isPlaying == true) { player?.stop(); player?.release(); player = null; status.text = "Beat stopped"; return }
        val uri = beatUri ?: run { status.text = "Import an instrumental first"; return }
        try {
            player = MediaPlayer().apply { setDataSource(this@MainActivity, uri); setOnPreparedListener { it.start(); status.text = "Playing instrumental" }; setOnErrorListener { _, _, _ -> status.text = "Could not play this audio file"; true }; prepareAsync() }
        } catch (_: Exception) { status.text = "Could not open instrumental" }
    }

    private fun toggleRecording() {
        if (recorder.isRecording()) { recorder.stop(); recordButton.text = "●  RECORD OVER BEAT"; status.text = "Finishing vocal take…"; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return }
        val output = File(getExternalFilesDir(null), "dodoLAB_take_${System.currentTimeMillis()}.wav")
        recordButton.isEnabled = false
        status.text = "Count-in… get ready"
        val countMs = (4 * 60_000L / bpm)
        countIn?.cancel()
        countIn = object : CountDownTimer(countMs, 250) {
            override fun onTick(ms: Long) { status.text = "Recording starts in ${(ms / 1000.0).let { String.format("%.1f", it) }}" }
            override fun onFinish() {
                try {
                    recorder.start(output) { file -> runOnUiThread { recordButton.isEnabled = true; recordButton.text = "●  RECORD OVER BEAT"; if (file != null) { takes.add(file); refreshTakes(); status.text = "Take saved · ${file.name}" } else status.text = "Recording failed. Check microphone permission." } }
                    if (beatUri != null) startBeatFromBeginning()
                    recordButton.text = "■  STOP RECORDING"
                    status.text = "Recording · perform your take"
                } catch (e: Exception) { recordButton.isEnabled = true; status.text = e.message ?: "Could not start microphone" }
            }
        }.start()
    }

    private fun startBeatFromBeginning() {
        val uri = beatUri ?: return
        try { player?.release(); player = MediaPlayer().apply { setDataSource(this@MainActivity, uri); setOnPreparedListener { it.start() }; prepareAsync() } } catch (_: Exception) {}
    }

    private fun refreshTakes() {
        trackList.removeAllViews()
        takes.forEachIndexed { index, file ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(4, 8, 4, 8) }
            row.addView(label("VOCAL ${index + 1}\n${file.name}", 11, white, true), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label("${file.length() / 1024} KB", 10, muted, false))
            trackList.addView(row)
        }
    }

    override fun onDestroy() { countIn?.cancel(); if (recorder.isRecording()) recorder.stop(); player?.release(); super.onDestroy() }
}
