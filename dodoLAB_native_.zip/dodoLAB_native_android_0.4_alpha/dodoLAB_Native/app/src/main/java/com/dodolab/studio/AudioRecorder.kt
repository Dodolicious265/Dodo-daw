package com.dodolab.studio

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean

/** Native PCM microphone capture. Writes standard 16-bit mono PCM WAV. */
class AudioRecorder {
    @Volatile private var recorder: AudioRecord? = null
    private val recording = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null

    fun isRecording() = recording.get()

    fun start(output: File, onFinished: (File?) -> Unit) {
        if (recording.get()) return
        val rate = 44100
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(min > 0) { "This device does not support the requested audio input format." }
        val bufferSize = maxOf(min * 2, 8192)
        val audio = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        require(audio.state == AudioRecord.STATE_INITIALIZED) { "Microphone could not be initialized." }
        output.parentFile?.mkdirs()
        recorder = audio
        recording.set(true)
        worker = Thread {
            var success = false
            try {
                FileOutputStream(output).use { stream ->
                    stream.write(ByteArray(44))
                    val buffer = ShortArray(bufferSize / 2)
                    audio.startRecording()
                    while (recording.get()) {
                        val count = audio.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                        if (count > 0) {
                            val bytes = ByteArray(count * 2)
                            for (i in 0 until count) {
                                val v = buffer[i].toInt()
                                bytes[i * 2] = (v and 0xff).toByte()
                                bytes[i * 2 + 1] = ((v shr 8) and 0xff).toByte()
                            }
                            stream.write(bytes)
                        }
                    }
                    stream.flush()
                }
                writeWavHeader(output, output.length() - 44, rate)
                success = true
            } catch (_: Exception) {
            } finally {
                try { audio.stop() } catch (_: Exception) {}
                audio.release()
                recorder = null
                recording.set(false)
                onFinished(if (success) output else null)
            }
        }.apply { name = "dodoLAB-audio-capture"; start() }
    }

    fun stop() {
        recording.set(false)
        try { recorder?.stop() } catch (_: Exception) {}
    }

    private fun writeWavHeader(file: File, dataLength: Long, sampleRate: Int) {
        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            val total = dataLength + 36
            fun text(s: String) = raf.write(s.toByteArray(Charsets.US_ASCII))
            fun i(v: Int) { raf.write(v and 255); raf.write((v shr 8) and 255); raf.write((v shr 16) and 255); raf.write((v shr 24) and 255) }
            fun s(v: Int) { raf.write(v and 255); raf.write((v shr 8) and 255) }
            text("RIFF"); i(total.toInt()); text("WAVE"); text("fmt "); i(16); s(1); s(1); i(sampleRate); i(sampleRate * 2); s(2); s(16); text("data"); i(dataLength.toInt())
        }
    }
}
