# dodoLAB Native Android — 0.4 Native Alpha

This is the first native Android source-code milestone for dodoLAB. It is an Android Studio/Gradle project, not an APK.

## Target
- Minimum Android: 7.0 (API 24)
- Target SDK: 28 for this early alpha's permission/storage behavior
- Native UI: Kotlin + Android Views
- Microphone capture: Android `AudioRecord`, 44.1 kHz, mono, 16-bit PCM WAV
- Beat playback: Android `MediaPlayer`

## Current functionality
- Requests microphone permission
- Imports an instrumental through Android's document picker
- Sets a tempo value
- Performs a one-bar count-in
- Starts microphone capture and instrumental playback
- Saves each vocal take as a WAV file in the app's external-files directory

## Important alpha limitations
- This is not yet a complete DAW and does not yet mix/export a combined song.
- The beat player and microphone recorder are separate Android APIs. Their start times are close but not sample-accurate; device latency varies.
- No live input monitoring is implemented yet.
- `AudioRecord` uses the device's microphone path; Bluetooth microphones/headsets may add latency.
- The app has not been compiled or tested on a physical Redmi 7 in this environment. Build and device testing are still required.
- The project currently uses the standard Android audio APIs as a compatibility-first stepping stone. A later engine milestone should use Oboe/AAudio with a native C++ callback and measured input/output latency.

## Build
Open this folder in Android Studio with Android Gradle Plugin 8.7.3 and a compatible Android SDK installed. Let Gradle sync, then build the `app` debug variant.

For phone-only development, a compatible Android IDE/build environment that supports modern Android Gradle Plugin projects is required. If that environment cannot support AGP 8.7.3, build from a cloud CI service or a computer. This ZIP does not contain a compiled APK.

## Next engineering milestone
1. Replace the separate `MediaPlayer`/`AudioRecord` start flow with a shared low-latency audio engine.
2. Add beat position tracking and measured input-latency compensation.
3. Add multi-take lanes and project persistence.
4. Add track FX processing and a real-time mixer.
